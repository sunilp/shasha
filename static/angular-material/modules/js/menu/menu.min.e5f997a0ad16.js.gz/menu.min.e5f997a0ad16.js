/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.6.0
 */
function MenuProvider(e){function n(){}return e("$mdMenu").setDefaults({methods:["placement"],options:n})}angular.module("material.components.menu",[]).factory("$mdMenu",MenuProvider),MenuProvider.$inject=["$$interimElementProvider"];