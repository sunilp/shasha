/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.9.7
 */
!function(a,i,r){"use strict";function e(a,i){function r(a){return a.attr("aria-valuemin",0),a.attr("aria-valuemax",100),a.attr("role","progressbar"),e}function e(r,e,n){i(e);var d=e[0],s=n.mdDiameter||48,c=s/48;d.style[a.CSS.TRANSFORM]="scale("+c+")",n.$observe("value",function(a){var i=t(a);e.attr("aria-valuenow",i)})}function t(a){return Math.max(0,Math.min(a||0,100))}return{restrict:"E",template:'<div class="md-spinner-wrapper"><div class="md-inner"><div class="md-gap"></div><div class="md-left"><div class="md-half-circle"></div></div><div class="md-right"><div class="md-half-circle"></div></div></div></div>',compile:r}}i.module("material.components.progressCircular",["material.core"]).directive("mdProgressCircular",e),e.$inject=["$mdConstant","$mdTheming"]}(window,window.angular);