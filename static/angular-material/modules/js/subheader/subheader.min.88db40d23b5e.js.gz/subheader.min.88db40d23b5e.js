/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.9.7
 */
!function(e,n,t){"use strict";function r(e,t,r){return{restrict:"E",replace:!0,transclude:!0,template:'<h2 class="md-subheader"><div class="md-subheader-inner"><span class="md-subheader-content"></span></div></h2>',compile:function(a,c,i){return function(a,c,s){function d(e){return n.element(e[0].querySelector(".md-subheader-content"))}r(c);var o=c[0].outerHTML;i(a,function(e){d(c).append(e)}),c.hasClass("md-no-sticky")||i(a,function(r){var i=t(n.element(o))(a);d(i).append(r),e(a,c,i)})}}}}n.module("material.components.subheader",["material.core","material.components.sticky"]).directive("mdSubheader",r),r.$inject=["$mdSticky","$compile","$mdTheming"]}(window,window.angular);