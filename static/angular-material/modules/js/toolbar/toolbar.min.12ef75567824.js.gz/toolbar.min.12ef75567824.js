/*!
 * Angular Material Design
 * https://github.com/angular/material
 * @license MIT
 * v0.9.7
 */
!function(t,n,o){"use strict";function e(t,o,e,r,a,i){return{restrict:"E",controller:n.noop,link:function(s,c,m){function l(){function n(n,o){c.parent()[0]===o.parent()[0]&&(f&&f.off("scroll",S),o.on("scroll",S),o.attr("scroll-shrink","true"),f=o,t(r))}function r(){d=c.prop("offsetHeight");var t=-d*h+"px";f.css("margin-top",t),f.css("margin-bottom",t),l()}function l(t){var n=t?t.target.scrollTop:p;$(),u=Math.min(d/h,Math.max(0,u+n-p)),c.css(o.CSS.TRANSFORM,"translate3d(0,"+-u*h+"px,0)"),f.css(o.CSS.TRANSFORM,"translate3d(0,"+(d-u)*h+"px,0)"),p=n,c.hasClass("md-whiteframe-z1")?u||i(function(){a.removeClass(c,"md-whiteframe-z1")}):u&&i(function(){a.addClass(c,"md-whiteframe-z1")})}var d,f,u=0,p=0,h=m.mdShrinkSpeedFactor||.5,S=t.throttle(l),$=e.debounce(r,5e3);s.$on("$mdContentLoaded",n)}r(c),n.isDefined(m.mdScrollShrink)&&l()}}}n.module("material.components.toolbar",["material.core","material.components.content"]).directive("mdToolbar",e),e.$inject=["$$rAF","$mdConstant","$mdUtil","$mdTheming","$animate","$timeout"]}(window,window.angular);